﻿// Copyright (c) Microsoft Corporation. All rights reserved.

#pragma once

#include <collection.h>
#include <ppltasks.h>
