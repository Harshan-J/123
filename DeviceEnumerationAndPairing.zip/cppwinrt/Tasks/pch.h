﻿#pragma once
#include <unknwn.h>
#include <winrt/Windows.ApplicationModel.Background.h>
#include <winrt/Windows.Devices.Enumeration.h>
#include <winrt/Windows.Foundation.h>
#include <winrt/Windows.Foundation.Collections.h>
#include <winrt/Windows.Storage.h>
